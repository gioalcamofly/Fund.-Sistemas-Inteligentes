# Search methods

import search

ab = search.GPSProblem('A', 'B', search.romania)
an = search.GPSProblem('A', 'N', search.romania)
on = search.GPSProblem('O', 'N', search.romania)
ob = search.GPSProblem('O', 'B', search.romania)
aa = search.GPSProblem('A', 'A', search.romania)

print "Camino A-B: "
print search.breadth_first_graph_search(ab).path()
print search.depth_first_graph_search(ab).path()
print search.busqueda1(ab).path()
print search.busqueda(ab).path()

print "Camino A-N: "
print search.breadth_first_graph_search(an).path()
print search.depth_first_graph_search(an).path()
print search.busqueda1(an).path()
print search.busqueda(an).path()

print "Camino O-N: "
print search.breadth_first_graph_search(on).path()
print search.depth_first_graph_search(on).path()
print search.busqueda1(on).path()
print search.busqueda(on).path()


print "Camino O-B: "
print search.breadth_first_graph_search(ob).path()
print search.depth_first_graph_search(ob).path()
print search.busqueda1(ob).path()
print search.busqueda(ob).path()


print "Camino A-A: "
print search.breadth_first_graph_search(aa).path()
print search.depth_first_graph_search(aa).path()
print search.busqueda1(aa).path()
print search.busqueda(aa).path()



#print search.busqueda(ab)
#print search.busqueda(ab)[1]
#print search.astar_search(ab).path()

# Result:
# [<Node B>, <Node P>, <Node R>, <Node S>, <Node A>] : 101 + 97 + 80 + 140 = 418
# [<Node B>, <Node F>, <Node S>, <Node A>] : 211 + 99 + 140 = 450
